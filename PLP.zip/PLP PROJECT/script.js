// script.js
document.addEventListener('DOMContentLoaded', function() {
    // Your JavaScript code goes here
    alert('We Welcome You To Muammer Gaddafi foundation!');
});
